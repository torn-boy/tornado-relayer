import { LegacyGasPrices } from './types';
export declare enum ChainId {
    MAINNET = 1,
    GOERLI = 5,
    BSC = 56,
    XDAI = 100,
    POLYGON = 137,
    OPTIMISM = 10,
    ARBITRUM = 42161,
    AVAX = 43114
}
export declare enum InstanceTokenSymbol {
    DAI = "dai",
    cDAI = "cdai",
    WBTC = "wbtc",
    USDT = "usdt",
    USDC = "usdc"
}
export type GasPricesConfig = {
    [chainId in ChainId]: LegacyGasPrices;
};
export declare const defaultGasPrices: GasPricesConfig;
type GasLimitConfig = {
    [chainId in ChainId]: number;
};
export declare const defaultWithdrawalGasLimit: GasLimitConfig;
type InstanceTokenGasLimitConfig = {
    [tokenSymbol in InstanceTokenSymbol]: number;
};
export declare const defaultInstanceTokensGasLimit: InstanceTokenGasLimitConfig;
export declare const optimismL1FeeOracleAddress = "0x420000000000000000000000000000000000000F";
export declare const offchainOracleAddress = "0x07D91f5fb9Bf7798734C3f606dB065549F6893bb";
export declare const multiCallAddress = "0xda3c19c6fe954576707fa24695efb830d9cca1ca";
export {};
