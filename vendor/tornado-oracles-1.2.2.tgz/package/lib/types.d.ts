import { BigNumberish, BytesLike } from 'ethers';
import { GasPriceKey, GetTxGasParamsRes } from '@tornado/gas-price-oracle/lib/services';
import { AvailableTokenSymbols } from '@tornado/tornado-config';
import { InstanceTokenSymbol } from './config';
export type LegacyGasPriceKey = GasPriceKey;
export type GasPriceParams = GetTxGasParamsRes;
export type LegacyGasPrices = {
    [gasPriceType in LegacyGasPriceKey]: number;
};
export type TxType = 'user_withdrawal' | 'relayer_withdrawal' | 'relayer_withdrawal_check_v4' | 'other';
export interface TransactionData {
    to: string;
    from?: string;
    nonce?: number;
    gasLimit?: BigNumberish;
    gasPrice?: BigNumberish;
    data?: string;
    value: BigNumberish;
    chainId?: number;
    type?: number;
    maxFeePerGas?: BigNumberish;
    maxPriorityFeePerGas?: BigNumberish;
}
export interface ITornadoFeeOracle {
    getGas: (tx?: TransactionData, type?: TxType) => Promise<string>;
    getGasPriceParams: (type?: TxType, speed?: LegacyGasPriceKey, bumpPercent?: number) => Promise<GasPriceParams>;
    getGasPrice: (type?: TxType, speed?: LegacyGasPriceKey, bumpPercent?: number) => Promise<string>;
    getGasLimit: (tx?: TransactionData, type?: TxType, bumpPercent?: number) => Promise<number>;
    fetchL1OptimismFee: (tx?: TransactionData) => Promise<string>;
    calculateRefundInETH: (tokenSymbol: InstanceTokenSymbol) => Promise<string>;
    calculateRefundInToken: (tokenPriceInEth: BigNumberish, tokenDecimals: string | number, tokenSymbol: InstanceTokenSymbol) => Promise<string>;
    calculateWithdrawalFeeViaRelayer: (type: TxType, tx: TransactionData, relayerFeePercent: number, currency: AvailableTokenSymbols, amount: string, decimals: number, refundInEth: BigNumberish, tokenPriceInEth?: BigNumberish) => Promise<string>;
}
export interface ITornadoPriceOracle {
    defaultPrices: TokenPrices;
    fetchPrices: (tokens?: Token[]) => Promise<TokenPrices>;
}
export type WithdrawalData = {
    contract: string;
    proof: BytesLike;
    args: [BytesLike, BytesLike, string, string, BigNumberish, BigNumberish];
};
export type TornadoPoolInstance = {
    currency: AvailableTokenSymbols;
    amount: number;
    decimals: number;
};
export type TokenSymbol = 'dai' | 'cdai' | 'usdc' | 'usdt' | 'wbtc' | 'torn';
export type Token = {
    tokenAddress: string;
    symbol: TokenSymbol;
    decimals: number;
};
export type TokenPrices = {
    [tokenSymbol in TokenSymbol]?: BigNumberish;
};
