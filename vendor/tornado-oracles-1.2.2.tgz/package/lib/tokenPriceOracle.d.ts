import { ITornadoPriceOracle, Token, TokenPrices } from './types';
export declare class TokenPriceOracle implements ITornadoPriceOracle {
    private tokens;
    private defaultTokenPrices;
    private oracle;
    private multiCall;
    private provider;
    /**
     *
     * @param rpcUrl
     * @param tokens
     */
    constructor(rpcUrl: string, tokens?: Token[], defaultTokenPrices?: TokenPrices);
    get defaultPrices(): TokenPrices;
    /**
     * Prepare data for MultiCall contract
     * @param {Token[]} tokens Tokens array
     * @returns Valid structure to provide to MultiCall contract
     */
    private prepareCallData;
    /**
     * Fetch actual tokens price rate to ETH from offchain oracles
     * @param {Token[]} tokens Token array
     * @returns {TokenPrices} Object with token price rate to ETH in WEI
     */
    fetchPrices(tokens?: Token[]): Promise<TokenPrices>;
}
