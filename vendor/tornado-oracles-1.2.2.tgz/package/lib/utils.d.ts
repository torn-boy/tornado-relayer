import { GasPriceParams, TransactionData } from './types';
import { BigNumber, BigNumberish } from 'ethers';
export declare function serializeTx(tx?: TransactionData | string): string;
export declare function calculateGasPriceInWei(gasPrice: GasPriceParams): BigNumber;
export declare function bump(value: BigNumberish, percent: number): BigNumber;
export declare function fromGweiToWeiHex(value: number | string): BigNumberish;
export declare function convertETHToToken(amountInWEI: BigNumberish, tokenDecimals: number | string, tokenPriceInWei: BigNumberish): BigNumber;
