import { TornadoFeeOracle } from './feeOracle';
import { ITornadoFeeOracle, TransactionData, TxType, LegacyGasPrices, LegacyGasPriceKey, GasPriceParams } from './types';
export declare class TornadoFeeOracleV5 extends TornadoFeeOracle implements ITornadoFeeOracle {
    private fallbackFeeOracle;
    constructor(chainId: number, rpcUrl: string, defaultGasPrices?: LegacyGasPrices);
    getGasLimit(tx?: TransactionData, type?: TxType, bumpPercent?: number): Promise<number>;
    getGasPriceParams(type?: TxType, speed?: LegacyGasPriceKey, bumpPercent?: number): Promise<GasPriceParams>;
}
