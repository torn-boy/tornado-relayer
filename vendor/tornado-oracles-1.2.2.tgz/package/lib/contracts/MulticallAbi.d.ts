import type { BaseContract, BigNumber, BytesLike, CallOverrides, PopulatedTransaction, Signer, utils } from 'ethers';
import type { FunctionFragment, Result } from '@ethersproject/abi';
import type { Listener, Provider } from '@ethersproject/providers';
import type { TypedEventFilter, TypedEvent, TypedListener, OnEvent } from './common';
export declare namespace MultiCall {
    type CallStruct = {
        to: string;
        data: BytesLike;
    };
    type CallStructOutput = [string, string] & {
        to: string;
        data: string;
    };
}
export interface MulticallAbiInterface extends utils.Interface {
    functions: {
        'multicall((address,bytes)[])': FunctionFragment;
    };
    getFunction(nameOrSignatureOrTopic: 'multicall'): FunctionFragment;
    encodeFunctionData(functionFragment: 'multicall', values: [MultiCall.CallStruct[]]): string;
    decodeFunctionResult(functionFragment: 'multicall', data: BytesLike): Result;
    events: {};
}
export interface MulticallAbi extends BaseContract {
    connect(signerOrProvider: Signer | Provider | string): this;
    attach(addressOrName: string): this;
    deployed(): Promise<this>;
    interface: MulticallAbiInterface;
    queryFilter<TEvent extends TypedEvent>(event: TypedEventFilter<TEvent>, fromBlockOrBlockhash?: string | number | undefined, toBlock?: string | number | undefined): Promise<Array<TEvent>>;
    listeners<TEvent extends TypedEvent>(eventFilter?: TypedEventFilter<TEvent>): Array<TypedListener<TEvent>>;
    listeners(eventName?: string): Array<Listener>;
    removeAllListeners<TEvent extends TypedEvent>(eventFilter: TypedEventFilter<TEvent>): this;
    removeAllListeners(eventName?: string): this;
    off: OnEvent<this>;
    on: OnEvent<this>;
    once: OnEvent<this>;
    removeListener: OnEvent<this>;
    functions: {
        multicall(calls: MultiCall.CallStruct[], overrides?: CallOverrides): Promise<[string[], boolean[]] & {
            results: string[];
            success: boolean[];
        }>;
    };
    multicall(calls: MultiCall.CallStruct[], overrides?: CallOverrides): Promise<[string[], boolean[]] & {
        results: string[];
        success: boolean[];
    }>;
    callStatic: {
        multicall(calls: MultiCall.CallStruct[], overrides?: CallOverrides): Promise<[string[], boolean[]] & {
            results: string[];
            success: boolean[];
        }>;
    };
    filters: {};
    estimateGas: {
        multicall(calls: MultiCall.CallStruct[], overrides?: CallOverrides): Promise<BigNumber>;
    };
    populateTransaction: {
        multicall(calls: MultiCall.CallStruct[], overrides?: CallOverrides): Promise<PopulatedTransaction>;
    };
}
