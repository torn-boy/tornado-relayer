import { Provider } from '@ethersproject/abstract-provider';
export declare const getOptimismL1FeeOracle: (provider: Provider) => import("./OptimismL1FeeOracleAbi").OptimismL1FeeOracleAbi;
export declare const getOffchainOracleContract: (provider: Provider) => import("./OffchainOracleAbi").OffchainOracleAbi;
export declare const getMultiCallContract: (provider: Provider) => import("./MulticallAbi").MulticallAbi;
