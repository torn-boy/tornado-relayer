import { Signer } from 'ethers';
import type { Provider } from '@ethersproject/providers';
import type { MulticallAbi, MulticallAbiInterface } from '../MulticallAbi';
export declare class MulticallAbi__factory {
    static readonly abi: readonly [{
        readonly inputs: readonly [{
            readonly components: readonly [{
                readonly internalType: "address";
                readonly name: "to";
                readonly type: "address";
            }, {
                readonly internalType: "bytes";
                readonly name: "data";
                readonly type: "bytes";
            }];
            readonly internalType: "struct MultiCall.Call[]";
            readonly name: "calls";
            readonly type: "tuple[]";
        }];
        readonly name: "multicall";
        readonly outputs: readonly [{
            readonly internalType: "bytes[]";
            readonly name: "results";
            readonly type: "bytes[]";
        }, {
            readonly internalType: "bool[]";
            readonly name: "success";
            readonly type: "bool[]";
        }];
        readonly stateMutability: "view";
        readonly type: "function";
    }];
    static createInterface(): MulticallAbiInterface;
    static connect(address: string, signerOrProvider: Signer | Provider): MulticallAbi;
}
