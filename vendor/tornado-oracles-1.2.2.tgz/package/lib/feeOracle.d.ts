import { GasPriceOracle } from '@tornado/gas-price-oracle';
import { BigNumberish } from 'ethers';
import { TransactionData, TxType, ITornadoFeeOracle, LegacyGasPriceKey, GasPriceParams } from './types';
import { JsonRpcProvider } from '@ethersproject/providers';
import { ChainId, InstanceTokenSymbol } from './config';
import { AvailableTokenSymbols } from '@tornado/tornado-config';
export declare abstract class TornadoFeeOracle implements ITornadoFeeOracle {
    protected chainId: ChainId;
    protected oracle: GasPriceOracle;
    protected provider: JsonRpcProvider;
    constructor(chainId: ChainId, rpcUrl: string, oracle: GasPriceOracle);
    /**
     * Because Optimism transaction published on Mainnet, for each OP transaction we need to calculate L1 security fee:
     * https://community.optimism.io/docs/developers/build/transaction-fees/#priority-fee
     * @param {TransactionData} tx Transaction data to estimate L1 additional fee
     * @returns {Promise<string>} Fee in WEI (MATIC)
     */
    fetchL1OptimismFee(tx?: TransactionData): Promise<string>;
    /**
     * Estimates next block gas for signed, unsigned or incomplete Tornado transaction
     * @param {TransactionData} tx Transaction data in web3 / ethers format
     * @param {TxType} txType Tornado transaction type: withdrawal by user, withdrawal by relayer or 'other'
     * @param {LegacyGasPriceKey} speed Preferred transaction speed, if uses legacy gas (before EIP-1559)
     * @returns {Promise<string>} Gas value in WEI (hex-format)
     */
    getGas(tx?: TransactionData, txType?: TxType, speed?: LegacyGasPriceKey): Promise<string>;
    /**
     * Estimate next block gas price
     * @param {TxType} type Tornado transaction type (to select correct default bump percent)
     * @param {LegacyGasPriceKey} speed Preferred transaction speed, if uses legacy gas (before EIP-1559)
     * @param {number} bumpPercent Gas bump percent to prioritize transaction
     * @returns {Promise<GasPriceParams>} Estimated gas price info in WEI (hexed) - legacy object with gasPrice property or
     * EIP-1559 object with maxFeePerGas and maxPriorityFeePerGas properties
     */
    getGasPriceParams(type?: TxType, speed?: LegacyGasPriceKey, bumpPercent?: number): Promise<GasPriceParams>;
    /**
     * Estimate next block gas price
     * @param {TxType} type Tornado transaction type (to select correct default bump percent)
     * @param {LegacyGasPriceKey} speed Preferred transaction speed, if uses legacy gas (before EIP-1559)
     * @param {number} bumpPercent Gas bump percent to prioritize transaction
     * @returns {Promise<string>} Gas price in WEI (hex string)
     */
    getGasPrice(type?: TxType, speed?: LegacyGasPriceKey, bumpPercent?: number): Promise<string>;
    /**
     * Estimates gas limit for transaction (or basic gas limit, if no tx data provided)
     * @param {TransactionData} tx Transaction data (object in web3 / ethers format)
     * @param {TxType} type Tornado transaction type: withdrawal by user, withdrawal by relayer, relayer fee check or 'other'
     * @returns {Promise<number>} Gas limit
     */
    abstract getGasLimit(tx?: TransactionData, type?: TxType): Promise<number>;
    /**
     * If user withdraw non-native tokens on ETH or Goerli, we need to calculate refund value:
     * if the withdrawal is successful, this amount will be returned to the user after the transfer to the relayer,
     * and if the relayer pays a commission and the transfer of tokens fails, this commission will remain to the relayer.
     *
     * Refund needed that recipient can use tokens after withdrawal (covers gas fee for send/swap)
     * @param {InstanceTokenSymbol} tokenSymbol Withdrawal token (currency) symbol - for example, 'dai'
     * @returns {Promise<string>} Refund amount in WEI (hexed number)
     */
    calculateRefundInETH(tokenSymbol: InstanceTokenSymbol): Promise<string>;
    /**
     * Get refund amount on ETH or Goerli in non-native token
     * @param {BigNumberish} tokenPriceInEth Token price in WEI in native currency
     * @param {string | number} tokenDecimals Token (currency) decimals
     * @param {InstanceTokenSymbol} tokenSymbol Withdrawal token (currency) symbol - for example, 'dai'
     * @returns {Promise<string>} Refund amount in WEI in selected token (hexed number)
     */
    calculateRefundInToken(tokenPriceInEth: BigNumberish, tokenDecimals: string | number, tokenSymbol: InstanceTokenSymbol): Promise<string>;
    /**
     * Estimates fee for withdrawal via relayer depending on type: gas bump percent is bigger, if it calculates by user,
     * so that the real commission from the relayer side is a little less,
     * in order to the relayer can send a transaction without fear that he will go into the red
     * @param {TxType} type Tornado transaction type: withdrawal costs calculation from user side or from relayer side
     * @param {TransactionData} tx Transaction data (object in web3 / ethers format)
     * @param {number} relayerFeePercent Relayer fee percent from the transaction amount (for example, 0.15 for BNB or 0.4 for ETH Mainnet)
     * @param {AvailableTokenSymbols | Uppercase<AvailableTokenSymbols>} currency Currency symbol
     * @param {number | string } amount Withdrawal amount in selected currency
     * @param {number | string } decimals Token (currency) decimals
     * @param {BigNumberish} [refundInEth=0] Refund in ETH, if withdrawed other tokens on Mainnet (not ETH)
     * @param {BigNumberish} [tokenPriceInEth] If withdrawing other token on Mainnet or Goerli, need to provide token price in ETH (in WEI)
     * @returns {Promise<string>} Fee in WEI (hexed string)
     */
    calculateWithdrawalFeeViaRelayer(type: TxType, tx: TransactionData, relayerFeePercent: number, currency: AvailableTokenSymbols | Uppercase<AvailableTokenSymbols>, amount: string | number, decimals: string | number, refundInEth?: BigNumberish, tokenPriceInEth?: BigNumberish): Promise<string>;
}
