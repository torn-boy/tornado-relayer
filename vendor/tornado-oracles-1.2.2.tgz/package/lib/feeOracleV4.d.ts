import { TornadoFeeOracle } from './feeOracle';
import { ITornadoFeeOracle, TransactionData, TxType, LegacyGasPrices } from './types';
export declare class TornadoFeeOracleV4 extends TornadoFeeOracle implements ITornadoFeeOracle {
    constructor(chainId: number, rpcUrl: string, defaultGasPrices?: LegacyGasPrices);
    getGasLimit(tx?: TransactionData, type?: TxType, bumpPercent?: number): Promise<number>;
}
