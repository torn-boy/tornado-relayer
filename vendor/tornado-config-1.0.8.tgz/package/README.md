# Tornado Cash contracts info

Technical information about all Tornado Cash contracts, token distribution and ENS domains

### Requirements

Node 12 or higher. This package doesn't have any build dependencies, but has type declarations file

### Licence

MIT